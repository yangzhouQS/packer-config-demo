export class CreateSysOperatorDto {}
