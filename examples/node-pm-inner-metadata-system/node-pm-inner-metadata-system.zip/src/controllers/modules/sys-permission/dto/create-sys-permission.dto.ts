export class CreateSysPermissionDto {}
