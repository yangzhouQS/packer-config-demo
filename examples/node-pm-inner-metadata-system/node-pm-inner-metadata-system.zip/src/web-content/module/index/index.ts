import App from "./App";

Vue.createApp(App)
  .use(ElementPlus)
  .mount("#app");
